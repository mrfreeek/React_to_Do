import './App.css';
import Dashboard from './Dashborad';

function App() {
  return (
    <div className="App">
     <Dashboard/>
    </div>
  );
}

export default App;
