import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Dashboard.css';

function Dashboard() {
  const [todos, setTodos] = useState([]);
  const [title, setTitle] = useState('');
  const [link, setLink] = useState('');

  useEffect(() => {
    axios.get('http://localhost:5000/todos').then((response) => {
      setTodos(response.data);
    });
  }, []);

  const handleAddTodo = (e) => {
    e.preventDefault();
    axios
      .post('http://localhost:5000/todos', { title, link })
      .then((response) => {
        setTodos([...todos, response.data]);
        setTitle('');
        setLink('');
      })
      .catch((error) => {
        console.log(error);
      });
  };
  const handleDeleteTodo = (id) => {
    axios
      .delete(`http://localhost:5000/todos/${id}`)
      .then((response) => {
        setTodos(todos.filter((todo) => todo._id !== id));
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleCheckTodo = (id, checked) => {
    axios
      .put(`http://localhost:5000/todos/${id}`, { checked: !checked })
      .then((response) => {
        setTodos(
          todos.map((todo) =>
            todo._id === id ? { ...todo, checked: !checked } : todo
          )
        );
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleDropTodo = (e, toPosition) => {
    const fromPosition = Number(e.dataTransfer.getData('position'));
    if (fromPosition !== toPosition) {
      axios
        .put(`http://localhost:5000/todos/${todos[fromPosition]._id}/position`, {
          position: toPosition,
        })
        .then((response) => {
          const newTodos = [...todos];
          const [removed] = newTodos.splice(fromPosition, 1);
          newTodos.splice(toPosition, 0, removed);
          setTodos(newTodos);
        })
        .catch((error) => {
          console.log(error);
        });
    }
  };

  return (
    <div className="dashboard">
      <h1>Dashboard</h1>
      <form onSubmit={handleAddTodo}>
        <input
          type="text"
          placeholder="Enter title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <input
          type="text"
          placeholder="Enter link"
          value={link}
          onChange={(e) => setLink(e.target.value)}
        />
        <button type="submit">Add Todo</button>
      </form>
      <ul>
        {todos.map((todo, index) => (
          <li
            key={todo._id}
            className={todo.checked ? 'checked' : ''}
            draggable
            onDragStart={(e) => {
              e.dataTransfer.setData('position', index);
            }}
            onDragOver={(e) => {
              e.preventDefault();
            }}
            onDrop={(e) => {
              handleDropTodo(e, index);
            }}
          >
            <input
              type="checkbox"
              checked={todo.checked}
              onChange={() => handleCheckTodo(todo._id, todo.checked)}
            />
            <a href={todo.link} target="_blank" rel="noreferrer">
              {todo.title}
            </a>
            <button onClick={() => handleDeleteTodo(todo._id)}>X</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Dashboard;
