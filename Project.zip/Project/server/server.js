const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();

// middleware
app.use(cors());
app.use(express.json());


mongoose.connect('mongodb+srv://sachin:auh8dWya9rmWIc0f@todo.ziljytv.mongodb.net/<dbname>?retryWrites=true&w=majority', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('Database connected successfully!');
}).catch((error) => {
  console.error('Error connecting to database:', error);
});


// database schema
const todoSchema = new mongoose.Schema({
  title: String,
  link: String,
  position: Number,
  checked: Boolean,
});

const Todo = mongoose.model('Todo', todoSchema);

// API routes
app.get('/todos', async (req, res) => {
  const todos = await Todo.find().sort({ position: 1 });
  res.json(todos);
});

app.post('/todos', async (req, res) => {
  const { title, link } = req.body;
  const todo = new Todo({
    title,
    link,
    position: await Todo.countDocuments(),
    checked: false,
  });
  await todo.save();
  res.json(todo);
});

app.put('/todos/:id', async (req, res) => {
  const { id } = req.params;
  const { checked } = req.body;
  await Todo.findByIdAndUpdate(id, { checked });
  res.json({ success: true });
});

app.put('/todos/:id/position', (req, res) => {
  const { id } = req.params;
  const { position } = req.body;

  Todo.findByIdAndUpdate(
    id,
    { position },
    { new: true },
    (err, todo) => {
      if (err) {
        console.log(err);
        return res.status(500).send('Server Error');
      }
      if (!todo) {
        return res.status(404).send('Todo not found');
      }
      return res.json(todo);
    }
  );
});


app.delete('/todos/:id', async (req, res) => {
  try {
    const deletedTodo = await Todo.findByIdAndDelete(req.params.id);
    if (!deletedTodo) {
      return res.status(404).json({ message: "Todo not found" });
    }
    res.status(200).json({ message: "Todo deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// start server
app.listen(5000, () => {
  console.log('Server started on port 5000');
});
